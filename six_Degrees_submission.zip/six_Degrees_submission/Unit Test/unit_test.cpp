/*
 * unit_test.cpp
 * Unit Testing file for Six Degrees 
 * Mirrors the normal main file but includes several functions 
 * CS 15 Project 2: Six Degrees of Collaboration
 *
 * by Kalead Bassma, April 2022
 */

using namespace std;
#include "SixDegrees.h"
#include <fstream>


void menu(string filename, six_degrees &program,  ostream &output, istream &input);
ifstream& read_file(string filename);
int main(int argc, char *argv[])
{
    six_degrees test;//initializes
    if(argc <= 1){ //ensures enough arguments are provided
        cout<<"Usage: ./the_SixDegrees dataFile [commandFile] [outputFile]"<<endl;

    } else if(argc == 2) { //allows for manual input
    
    menu(argv[1],test,cout,cin);

   

    return 0;
}
}
void menu(string filename, six_degrees &program,  ostream &output, istream &input){
string input_string; 
ifstream read;
string test_file;


while(input_string!="q"){
cout<<"Unit Test"<<endl;
cout<<"s: Search for artist that does not exist, n: Not search"<<endl;
cout<<"c: collision detection"<<endl;
cout<<"np: no path example"<<endl;
cout<<"f: full demo"<<endl;
cin>>input_string;
if(input_string=="s"){
    cout<<"We will search for Beethoven who is not in the list"<<endl;
    test_file="database_check.in";
    read.open(test_file);
    program.start(filename,read,output);
    read.close();
    
} else if(input_string=="q"){
    break;
} else if(input_string=="n"){

    cout<<"We will exclude our source artist in our not search. This will thrown an exception"<<endl;
    test_file="not_check.in";
    read.open(test_file);
    program.start(filename,read,output);
     read.close();
} else if(input_string=="c"){
    
    cout<<"We will make our source artist and our destination artist the same in our bfs search"<<endl;
    test_file="collision.txt";
    read.open(test_file);
    program.start(filename,read,output);
     read.close();
    

} else if(input_string=="np"){
    cout<<"Avril Lavigne has no collaborations. A bfs or dfs will produce no path"<<endl;
    
    test_file="no_path.in";
    read.open(test_file);
    program.start(filename,read,output);
     read.close();

} else if(input_string=="f"){
    cout<<"This will execute a bfs, a not search that eliminates the closest collection, and a dfs"<<endl;
    
    test_file="full_test.in";
    read.open(test_file);
    program.start(filename,read,output);
     read.close();
}


}
}

