/** Kalead Bassma
 ** CS61M1
 ** six_degrees.cpp
 **
*/

#include "SixDegrees.h"
#include <fstream>
#include <sstream>
#include <queue>

six_degrees::six_degrees(){
//nullary
};


six_degrees::~six_degrees(){
//most of the datastructures are from the standard library templates so they have destructors already
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: populate()
 * purpose: fill the graph
 *
 *
 * parameters: filename as a string (passed in as an arg in start)
 * returns: void
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void six_degrees::populate(string filename){
 //Open the given file
    queue<Artist> q;
    ifstream infile;
    infile.open(filename);
    if (infile.fail()) {
        cerr << "ERROR: Error opening file, please check file name: "
             << filename << endl;
        exit(EXIT_FAILURE);
    }
    string artist_name;
    string line;
    string song_name;

  //creates stringstream to store the file information
    istringstream line_stream;
    //Getline of the artist name
    //Make the artist
    //Insert the artist into the queue
    //Add the song to their discography
    //Then, make a seperate function that creates the edges.

    while(!infile.eof()){
        getline(infile,line); //get artist name
        Artist insertion(line); //create an artist instance
        while(line!="*"){
        getline(infile,line); //get the song name
        if(line!="*"){ //erroneously added sentinel character as line
        insertion.add_song(line); //adds a song
        }
        line_stream.clear(); //clears it
        }

        insert_vertex(insertion);
        q.push(insertion);
    }



    /*the below creates the edges by checking collaborations with each artist against eachother
    / 1. We copy the vectors
    / 2. We iterate over the stack and use the get_collaboration() function to see if they worked with eachother
    / 3. We then insert the edge into the graph if they have a collaboration.
    */


    queue<Artist> s(q);   //Copy the vector
           while(q.empty()==false){

            while(s.empty()==false){
                if(q.front()!=s.front()){
            string curr_song=q.front().get_collaboration(s.front());
            if(curr_song!=""){
            insert_edge(q.front(),s.front(),curr_song);
        }
                }
            s.pop();
            }
            q.pop();
            s=q;
           }

    infile.close();


}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: print_path()
 * purpose: Prints the stack/path returned by report_path in the required format
 *
 *
 * parameters: User inputted artist names as a string
 * returns: void
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void six_degrees::print_path(ostream& output, stack<Artist> path,const Artist &source, const Artist &dest){

    //copy the stack for simplicity
     if(path.empty()){
         output<<"A path does not exist between "<<source<<" and "<<dest<<endl;
     } else{

    while(path.size()!=1){ //checks to make sure size!=1 to make sure there isn't an attempt to access empty index
        Artist first=path.top();
        output<<"\""<<path.top().get_name()<<"\""<<" collaborated with ";
        path.pop();
        output<<"\""<<path.top().get_name()<<"\""<<" in "<<"\""<<degrees.get_edge(path.top(),first)<<"\""<<endl;

    }
    output<<"**"<<endl;
    }

}




/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: start()
 * purpose: Driver function
 *
 *
 * parameters: Filename as a string (passed in as argv), input type (cin or ifstream), and output (cout or ofstream)
 * returns: void
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void six_degrees::start(string filename,istream& input, ostream& output_type){
populate(filename);
string command;
string source;
string dest;




while(input){

    input>>command; //used to be a getline() but had issues reading when passing fstream

    if(command=="dfs"){
    input.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //clears whitespace
    getline(input,source);
    getline(input,dest);
    if(database_check(source) && database_check(dest)){
 
    degrees.dfs(source,dest);
    
    print_path(output_type,degrees.report_path(source,dest), source, dest);
    }
    } else if(command=="bfs"){
      input.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    getline(input,source);
    getline(input,dest);
    if(database_check(source) && database_check(dest)){
    degrees.bfs(source,dest);
    print_path(output_type,degrees.report_path(source,dest), source, dest);
    }

    } else if(command=="not"){
      input.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    getline(input,source);
    getline(input,dest);
    string list;
    vector<Artist>exclude;

    while(list!="*"){
        getline(input,list);
        if(list==source || list==dest){
            throw invalid_argument("Cannot exclude the artist you are searching for");
        }
        exclude.push_back(list); //uses getter to return artist instance

    }
    if(database_check(source) && database_check(dest)){
    if(exclusion_check(exclude)){
        degrees.not_search(source,dest,exclude);
    print_path(output_type,degrees.report_path(source,dest), source, dest);
    }
    }

    } else if(command=="quit"){
        break;
    } else if(command=="print"){
        degrees.print_graph(output_type);
        }else {
        output_type<<command<<" is not a command. Please try again"<<endl;
    }

}


}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: database_check()
 * purpose: Checks to see if the user provided artist is valid
 *
 *
 * parameters: User input as a string
 * returns: bool depending on if artist is in the graph
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


bool six_degrees::database_check(const Artist &source){

    if(degrees.is_vertex(source)==false){
        cout<<source<<" was not found in the data set :("<<endl;
        return false;
    }

        return true;


}
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: exclusion_check()
 * purpose: Iterates through user inputted exclusion vector for not searches
 *          checks if artists are in the graph before doing the search.
 *
 * parameters: User inputted vector
 * returns: bool
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

bool six_degrees::exclusion_check(const vector<Artist> exclude){

    for(int i=0;i<exclude.size();i++){
        if(database_check(exclude[i])==false){ //if any artist isnt found, breaks the loop

            return false;
        }
     }

     return true;

}
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: insert_vertex()
 * purpose: Accesses collabgraph insert_vertex function for simplicity
 *
 *
 * parameters: Artist object
 * returns: void
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void six_degrees::insert_vertex(const Artist &source){

    degrees.insert_vertex(source);

}
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * function: insert_edge()
 * purpose: Accesses collabgraph insert_edge function for simplicity
 *
 *
 * parameters: Artist objects and song as a string
 * returns: void
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void six_degrees::insert_edge(const Artist &a1, const Artist &a2,const std::string &song){
    degrees.insert_edge(a1,a2,song);
}


ostream& six_degrees::output_file(string output_file){

 ofstream ofFile(output_file, std::ios_base::app); // appends info to the file whenever called
     ofFile.close();
 return ofFile;


}
