#include "CollabGraph.h"
#include "Artist.h"

/** Kalead Bassma
 ** CS61M1
 ** SixDegrees.h
 **
*/


#ifndef SIXDEGREES_H
#include <string>
#include <queue>
using namespace std;

class six_degrees{
public:
six_degrees();
six_degrees(const )
~six_degrees();

void populate(string filename); //takes the filename

void print_path(ostream& output,stack<Artist> path, const Artist &source, const Artist &dest); //basically does a bfs

void start(string filename,istream& input, ostream& output_type);


bool database_check(const Artist &source);
bool exclusion_check(const vector<Artist> exclude);
ostream& output_file(string output_file);
private:

//helper functions that invoke the  functions in CollabGraph
void insert_vertex(const Artist &source); 
void insert_edge(const Artist &a1, const Artist &a2,const std::string &song);

                     
CollabGraph degrees;
queue<Artist>dfs_helper; //used to store artists for recursive calls


};
#endif
