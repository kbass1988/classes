/*
 * main.cpp
 * Maine file for SixDegrees Project
 * CS 15 Project 2: Six Degrees of Collaboration
 *
 * by Kalead Bassma, April 2022
 */

using namespace std;
#include "SixDegrees.h"
#include <fstream>
int main(int argc, char *argv[])
{
    six_degrees test;//initializes
    if(argc <= 1){ //ensures enough arguments are provided
        cout<<"Usage: ./the_SixDegrees dataFile [commandFile] [outputFile]"<<endl;

    } else if(argc == 2) { //allows for manual input
    test.start(argv[1],cin,cout);

    } else if(argc==3){ //takes in an input file
    ifstream infile; //reads the input file and passes into the start function

    infile.open(argv[2]);
    if (infile.fail()) {
        cerr << "ERROR: Error opening file, please check file name: "
             << argv[2] << endl;
        exit(EXIT_FAILURE);
    }

        test.start(argv[1],infile,cout);

       infile.close();

    }else if(argc == 4){ //takes in an input file and designates an output file

    string outputfile=argv[3];
      ifstream infile; //reads the input file and passes into the start function
    infile.open(argv[2]);
    if (infile.fail()) {
        cerr << "ERROR: Error opening file, please check file name: "
             << argv[3] << endl;
        exit(EXIT_FAILURE);
    }

    ofstream ofFile(outputfile, std::ios_base::app); // appends info to the file whenever called

    test.start(argv[1],infile,ofFile);
    ofFile.close();
    }


    return 0;
}
